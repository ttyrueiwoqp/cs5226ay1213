<?php

class Application_Model_DBConnect{
    
    public static function dbconnect($username, $dbpassword, $query){
        
        $result=array();
        if(isset($_SESSION['ROLE']))
            $role=OCI_SYSDBA;
        else
            $role=null;
        $con = oci_connect($username, $dbpassword, '//localhost:1521/OracledatabaXDB',null,$role);
        if (!$con){
    		   $result[0]='APPLICATION_ERROR';
                  }
        // Perform Query
        $s = oci_parse($con, $query);
        oci_execute($s);
        
        oci_fetch_all($s, $result);

        if (!$result) {
            $result[0]='APPLICATION_ERROR';
    	   
    	}
            oci_close($con);
        return $result;
    }
    
    public static function executeSPForCursor($username, $dbpassword, $procCall){
        if(isset($_SESSION['ROLE']))
            $role=OCI_SYSDBA;
        else
            $role=null;
        $con = oci_connect($username, $dbpassword, '//localhost:1521/OracledatabaXDB',null,$role);
        $s = oci_parse($con, $procCall);
        $refcur = oci_new_cursor($con);
        oci_bind_by_name($s, ':rc', $refcur, -1, OCI_B_CURSOR);
        oci_execute($s);
        oci_execute($refcur);
        return $refcur;
    }
    
    public static function executeSP($username, $dbpassword, $procCall){
        if(isset($_SESSION['ROLE']))
            $role=OCI_SYSDBA;
        else
            $role=null;
        $con = oci_connect($username, $dbpassword, '//localhost:1521/OracledatabaXDB',null,$role);
        $s = oci_parse($con, $procCall);
        oci_bind_by_name($s, ':ret', $retVal, 20);
        oci_execute($s);
        return $retVal;
        
    } 
    
}
?>
