<?php

class IndexController extends Zend_Controller_Action
{

    public function init()
    {
        /* Initialize action controller here */
        error_reporting(0);
    	Zend_Session::start();
        include 'C:\wamp\www\dbtuning\application\models\dbtuningmodel.php';
    }

    public function indexAction()
    {
        if(isset($_GET['loggedout'])){
    		header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
    		header("Cache-Control: no-cache");
    		header("Pragma: no-cache");
    	}
    	if($this->getRequest()->isPost()){
    		$this->view->post=true;
    		$username=trim($_POST['loginUsername']);
    		$password=$_POST['loginpwd'];
                if($_POST['loginRole']=='OCI_SYSDBA'){
                    $role=OCI_SYSDBA;
                }else{
                    $role=null;
                }
                $con = oci_connect($username, $password, '//localhost:1521/OracledatabaXDB',null,$role);
                if (!$con)
    		{
    			$this->view->wrongCredentials=true;
    		}else{
    	
    				$this->view->wrongCredentials=false;
                                $_SESSION['USERNAME']=$username;
                                $_SESSION['PASSWORD']=$password;
                                $_SESSION['ROLE']=$role;
    				$this->_redirect("/index/home");
                                
    		     }
    	} //End of post processing
        
    } //End of index action
     
    public function homeAction(){
        
        if(isset($_SESSION['USERNAME'])){
            
        }else{
                $this->_redirect("/index/logout");
             }
        
    }
    
    
    public function logoutAction(){
    	$auth = Zend_Auth::getInstance();
    	$auth->clearIdentity();
    	Zend_Session::destroy();
    	session_destroy();
    	$this->_redirect("/index/index?loggedout=".$_SESSION['USERNAME']);
    	unset($_SESSION['USERNAME']);
        unset($_SESSION['PASSWORD']);
    }
    
    
    public function sharedpoolAction(){
        
     if(isset($_SESSION['USERNAME'])){   
        $querySharedPool="select sum(bytes)/(1024*1024) as SHAREDPOOL_IN_MB from v\$sgastat where pool ='shared pool'";   
        $sysResult=Application_Model_DBConnect::dbconnect($_SESSION['USERNAME'],$_SESSION['PASSWORD'],$querySharedPool);
        $this->view->sharedPool=intVal($sysResult['SHAREDPOOL_IN_MB'][0]);
        
        /*
         * Code get the cache hit ratios
         * 
         */
        
        $procSharedData1="select sum(gets),sum(getmisses),(1-(sum(getmisses)/(sum(gets) + sum(getmisses))))*100 HIT_RATE  from v\$rowcache";
        $resultSharedData1=Application_Model_DBConnect::dbconnect($_SESSION['USERNAME'],$_SESSION['PASSWORD'], $procSharedData1);
        $procSharedData2="select sum(Pins),sum(reloads),((sum(reloads)/sum(pins))*100) as RELOAD_RATIO from v\$librarycache";
        $resultSharedData2=Application_Model_DBConnect::dbconnect($_SESSION['USERNAME'],$_SESSION['PASSWORD'], $procSharedData2);
        $procSharedData3="select sum(pins),sum(reloads),sum(pins)/(sum(pins) + sum(reloads))as HIT_RATIO from v\$librarycache";
        $resultSharedData3=Application_Model_DBConnect::dbconnect($_SESSION['USERNAME'],$_SESSION['PASSWORD'], $procSharedData3);
        
        $this->view->hitRate=round(floatval($resultSharedData1['HIT_RATE'][0]),2);
        $this->view->reloadRatio=round(floatval($resultSharedData2['RELOAD_RATIO'][0]),2);
        $this->view->hitRatio=round(floatval($resultSharedData3['HIT_RATIO'][0]),2);
        
        
        //date processing stuff
        $curTime=strtotime("Now");
        //Can generate reports only for 8 days prior to today
        $startTime=$curTime-(60*60*24*8);
        $curDate = date( 'Y-m-d', $curTime );
        $nodays=  intval(($curTime-$startTime)/ (60 * 60 * 24));
        $this->view->dateArray=array();
        for($i=0;$i<=$nodays;$i++){
            $newdate=strtotime ( '-'.$i .' day' , strtotime ( $curDate ) ) ;
            $newdate = date ( 'Y-m-d' , $newdate );
            $this->view->dateArray[$i]=$newdate;
        }
        //Get the snaps for Today
        $procGetSnapsofToday="call GET_SNAPS_ONDATE('".$curDate."',:rc)";
        $resultToday=Application_Model_DBConnect::executeSPForCursor($_SESSION['USERNAME'],$_SESSION['PASSWORD'], $procGetSnapsofToday);
        $valToday=array();
        $i=0;
         while($i<100) {
                $temp=oci_fetch_array($resultToday, OCI_ASSOC);
            if($temp==false)
                break;
            $valToday[$i]= $temp;
            $i++;
            }
            
            $this->view->todaySnaps=$valToday;
        //End of get the snaps for today
        
        //Ajax Processing
       if($_GET["q"]!=''){
            $procGetSnapsonDate="call GET_SNAPS_ONDATE('".$_GET["q"]."',:rc)";
            $resultSnaps=Application_Model_DBConnect::executeSPForCursor($_SESSION['USERNAME'],$_SESSION['PASSWORD'], $procGetSnapsonDate);
            $abc=array(); 
            $i=0;
            while($i<100) {
                $temp=oci_fetch_array($resultSnaps, OCI_ASSOC);
            if($temp==false)
                break;
            $abc[$i]= $temp;
            $i++;
            }
            echo "<table style=\"margin-left:5px;\">
                <tr>
                <td style=\"width: 233px;\">Select the upper Snap Time</td>
                <td style=\"width: 233px;\"><select id=\"upperSnap\" name=\"upperSnap\" style=\"width: 200px;\">";
                    for($count=0;$count<count($abc);$count++){
                    echo "<option value=\"".$abc[$count]['SNAP_ID']."\">";
                    echo $abc[$count]['SNAP_TIMES']."</option>";

                    } echo "<select/></td>";
                "</tr>";

                echo "<tr>
                <td style=\"width: 233px;\">Select the upper Snap Time</td>
                <td style=\"width: 233px;\"><select id=\"lowerSnap\" name=\"lowerSnap\" style=\"width: 200px;\">";
                    for($count=0;$count<count($abc);$count++){
                    echo "<option value=\"".  $abc[$count]['SNAP_ID']. "\">";
                    echo $abc[$count]['SNAP_TIMES']. "</option>";

                    } echo "<select/></td>";
                "</tr></table>";exit;

       }
       
       
        //Post processing
        if($this->getRequest()->isPost()){
            
            $selectedDate=$_POST['selectedDate'];
            if($_POST['todaylowerSnap']==$_POST['todayupperSnap']){
                    $upperSnap=$_POST['upperSnap'];
                    $lowerSnap=$_POST['lowerSnap'];
            }else{
                   $upperSnap=$_POST['todayupperSnap'];
                    $lowerSnap=$_POST['todaylowerSnap'];
                 }
            $procGetSharedPoolDayAvg="call GET_SHAREDPOOL_AGGREGATES('".$selectedDate."',:ret)";
            $resultShared=Application_Model_DBConnect::executeSP($_SESSION['USERNAME'],$_SESSION['PASSWORD'], $procGetSharedPoolDayAvg);
            $this->view->dayAvg=$resultShared;
            $this->view->selectedDate=$selectedDate;
            $this->view->upperSnap=$upperSnap;
            $this->view->lowerSnap=$lowerSnap;
            $procBreakDown="call GET_BREAKDOWN_SP(".$lowerSnap.",".$upperSnap.",:ret)";
            $resultBreak=Application_Model_DBConnect::executeSP($_SESSION['USERNAME'],$_SESSION['PASSWORD'], $procBreakDown);
            $this->view->breakAvg=$resultBreak;

        }
     }else{
             $this->_redirect("/index/logout");
          }  
        
    }
    
    
    
    
    public function memoryareaAction(){
        
        if(isset($_SESSION['USERNAME'])){
            
         
        $queryMemory="select name, value/(1024*1024) as MEMORY_AREA
                            from v\$pgastat where name = 'over allocation count'
                            or name = 'aggregate PGA auto target'";   
        $sysResult=Application_Model_DBConnect::dbconnect($_SESSION['USERNAME'],$_SESSION['PASSWORD'],$queryMemory);
        $this->view->memoryarea=intval($sysResult['MEMORY_AREA'][0]);
        
        $queryOptimalMem="select min(pga_target_for_estimate)/(1024*1024) AS OPTIMUM_MEM from v\$pga_target_advice where estd_overalloc_count=0 and pga_target_for_estimate<".$this->view->memory*1024*1024;
        $this->view->resultOptimumMem=Application_Model_DBConnect::dbconnect($_SESSION['USERNAME'],$_SESSION['PASSWORD'],$queryOptimalMem);

        $queryGetEstimate="select name c1,count c2,decode(total, 0, 0, round(count*100/total)) c3
                                from(select name,value count,(sum(value) over ()) total
                                from v\$sysstat
                                where name like 'workarea exec%')";
        $this->view->estimate=Application_Model_DBConnect::dbconnect($_SESSION['USERNAME'],$_SESSION['PASSWORD'],$queryGetEstimate);
        //var_dump($this->view->estimate);exit;
        $c20=intval($this->view->estimate['C2'][0]);
        $c21=intval($this->view->estimate['C2'][1]);
        $c22=intval($this->view->estimate['C2'][2]);
        
        if($c21>10 && $c22==0){
            $this->view->memoryestimate=46;
        }elseif($c22>0){
            $this->view->memoryestimate=16;
        }else{
            $this->view->memoryestimate=82;
        }
        
        /*
         * Code get the cache hit ratios
         * 
         */
        
       
        
            
            //date processing stuff
        //date processing stuff
        $curTime=strtotime("Now");
        //Can generate reports only for 8 days prior to today
        $startTime=$curTime-(60*60*24*8);
        $curDate = date( 'Y-m-d', $curTime );
        $nodays=  intval(($curTime-$startTime)/ (60 * 60 * 24));
        $this->view->dateArray=array();
        for($i=0;$i<=$nodays;$i++){
            $newdate=strtotime ( '-'.$i .' day' , strtotime ( $curDate ) ) ;
            $newdate = date ( 'Y-m-d' , $newdate );
            $this->view->dateArray[$i]=$newdate;
        }
        //Get the snaps for Today
        $procGetSnapsofToday="call GET_SNAPS_ONDATE('".$curDate."',:rc)";
        $resultToday=Application_Model_DBConnect::executeSPForCursor($_SESSION['USERNAME'],$_SESSION['PASSWORD'], $procGetSnapsofToday);
        $valToday=array();
        $i=0;
         while($i<100) {
                $temp=oci_fetch_array($resultToday, OCI_ASSOC);
            if($temp==false)
                break;
            $valToday[$i]= $temp;
            $i++;
            }
            
            $this->view->todaySnaps=$valToday;
        //End of get the snaps for today
        
        //Ajax Processing
       if($_GET["q"]!=''){
            $procGetSnapsonDate="call GET_SNAPS_ONDATE('".$_GET["q"]."',:rc)";
            $resultSnaps=Application_Model_DBConnect::executeSPForCursor($_SESSION['USERNAME'],$_SESSION['PASSWORD'], $procGetSnapsonDate);
            $abc=array(); 
            $i=0;
            while($i<100) {
                $temp=oci_fetch_array($resultSnaps, OCI_ASSOC);
            if($temp==false)
                break;
            $abc[$i]= $temp;
            $i++;
            }
            echo "<table style=\"margin-left:5px;\">
            <tr>
            <td style=\"width: 233px;\">Select the upper Snap Time</td>
            <td style=\"width: 233px;\"><select id=\"upperSnap\" name=\"upperSnap\" style=\"width: 200px;\">";
                for($count=0;$count<count($abc);$count++){
                echo "<option value=\"".$abc[$count]['SNAP_ID']."\">";
                echo $abc[$count]['SNAP_TIMES']."</option>";

                } echo "<select/></td>";
            "</tr>";

            echo "<tr>
            <td style=\"width: 233px;\">Select the upper Snap Time</td>
            <td style=\"width: 233px;\"><select id=\"lowerSnap\" name=\"lowerSnap\" style=\"width: 200px;\">";
                for($count=0;$count<count($abc);$count++){
                echo "<option value=\"".  $abc[$count]['SNAP_ID']. "\">";
                echo $abc[$count]['SNAP_TIMES']. "</option>";

                } echo "<select/></td>";
            "</tr></table>";exit;

       }
       
       //Post processing
        if($this->getRequest()->isPost()){
            $selectedDate=$_POST['selectedDate'];
            if($_POST['todaylowerSnap']==$_POST['todayupperSnap']){
                    $upperSnap=$_POST['upperSnap'];
                    $lowerSnap=$_POST['lowerSnap'];
            }else{
                   $upperSnap=$_POST['todayupperSnap'];
                    $lowerSnap=$_POST['todaylowerSnap'];
                 }
                 
            $procGetSharedPoolDayAvg="call GET_PGATARGET_AGGREGATES('".$selectedDate."',:ret)";
            $resultShared=Application_Model_DBConnect::executeSP($_SESSION['USERNAME'],$_SESSION['PASSWORD'], $procGetSharedPoolDayAvg);
            $this->view->dayAvg=round(floatval($resultShared)/(1024*1024),2);
            $this->view->selectedDate=$selectedDate;
            $this->view->upperSnap=$upperSnap;
            $this->view->lowerSnap=$lowerSnap;
            $procBreakDown="call get_pgatarget_sp(".$lowerSnap.",".$upperSnap.",:ret)";
            $resultBreak=Application_Model_DBConnect::executeSP($_SESSION['USERNAME'],$_SESSION['PASSWORD'], $procBreakDown);
            $this->view->breakAvg=round(floatval($resultBreak)/(1024*1024),2);
                 
                 
        }
            
        }else{
                 $this->_redirect("/index/logout");
             }
        
    }
      
    
    public function rollbackAction(){
        
        if(isset($_SESSION['USERNAME'])){
            
        $queryRollback1="select name, waits, gets, waits/gets as Ratio
                             from v\$rollstat a, v\$rollname b
                            where a.usn = b.usn";   
        $resultRollback1=Application_Model_DBConnect::dbconnect($_SESSION['USERNAME'],$_SESSION['PASSWORD'],$queryRollback1);
        $this->view->rollData1=$resultRollback1;
        
        $queryWaitStatistics="select class, count
                               from v\$waitstat where class in ('free list',
                               'system undo header','system undo block','undo header','undo block') group by class,count";
        $this->view->resultWaitStatistics =Application_Model_DBConnect::dbconnect($_SESSION['USERNAME'],$_SESSION['PASSWORD'],$queryWaitStatistics);
        // var_dump($this->view->resultWaitStatistics);exit;   
            
        }else{
                 $this->_redirect("/index/logout");
             }
        
    }
    
    
    
    public function buffercacheAction(){
        if(isset($_SESSION['USERNAME'])){
         
        $queryBufferCache="select size_for_estimate as BUFFER_CACHE from v\$db_cache_advice where size_factor=1";   
        $sysResult=Application_Model_DBConnect::dbconnect($_SESSION['USERNAME'],$_SESSION['PASSWORD'],$queryBufferCache);
        $this->view->bufferCache=intVal($sysResult['BUFFER_CACHE'][0]);  
        
        $queryHitRatio="SELECT (s1.value + s2.value - s3.value) / (s1.value + s2.value) 
                        AS HIT_RATIO
                        FROM   v\$sysstat s1, v\$sysstat s2, v\$sysstat s3
                        WHERE  s1.name = 'db block gets'
                        AND    s2.name = 'consistent gets'
                        AND    s3.name = 'physical reads' ";
        $resultRatio=Application_Model_DBConnect::dbconnect($_SESSION['USERNAME'],$_SESSION['PASSWORD'],$queryHitRatio);
        $this->view->hitRatio=round(floatval($resultRatio['HIT_RATIO'][0]),5)*100; 
        
        $queryForSizeEstimate="select size_for_estimate,size_factor,estd_physical_read_factor  from v\$db_cache_advice where estd_physical_read_factor=1 and size_factor<1";
        $this->view->resultEstimate=Application_Model_DBConnect::dbconnect($_SESSION['USERNAME'],$_SESSION['PASSWORD'],$queryForSizeEstimate);

        //date processing stuff
        $curTime=strtotime("Now");
        //Can generate reports only for 8 days prior to today
        $startTime=$curTime-(60*60*24*8);
        $curDate = date( 'Y-m-d', $curTime );
        $nodays=  intval(($curTime-$startTime)/ (60 * 60 * 24));
        $this->view->dateArray=array();
        for($i=0;$i<=$nodays;$i++){
            $newdate=strtotime ( '-'.$i .' day' , strtotime ( $curDate ) ) ;
            $newdate = date ( 'Y-m-d' , $newdate );
            $this->view->dateArray[$i]=$newdate;
        }
        //Get the snaps for Today
        $procGetSnapsofToday="call GET_SNAPS_ONDATE('".$curDate."',:rc)";
        $resultToday=Application_Model_DBConnect::executeSPForCursor($_SESSION['USERNAME'],$_SESSION['PASSWORD'], $procGetSnapsofToday);
        $valToday=array();
        $i=0;
         while($i<100) {
                $temp=oci_fetch_array($resultToday, OCI_ASSOC);
            if($temp==false)
                break;
            $valToday[$i]= $temp;
            $i++;
            }
            
            $this->view->todaySnaps=$valToday;
        //End of get the snaps for today
        
        //Ajax Processing
       if($_GET["q"]!=''){
            $procGetSnapsonDate="call GET_SNAPS_ONDATE('".$_GET["q"]."',:rc)";
            $resultSnaps=Application_Model_DBConnect::executeSPForCursor($_SESSION['USERNAME'],$_SESSION['PASSWORD'], $procGetSnapsonDate);
            $abc=array(); 
            $i=0;
            while($i<100) {
                $temp=oci_fetch_array($resultSnaps, OCI_ASSOC);
            if($temp==false)
                break;
            $abc[$i]= $temp;
            $i++;
            }
            echo "<table style=\"margin-left:5px;\">
            <tr>
            <td style=\"width: 233px;\">Select the upper Snap Time</td>
            <td style=\"width: 233px;\"><select id=\"upperSnap\" name=\"upperSnap\" style=\"width: 200px;\">";
                for($count=0;$count<count($abc);$count++){
                echo "<option value=\"".$abc[$count]['SNAP_ID']."\">";
                echo $abc[$count]['SNAP_TIMES']."</option>";

                } echo "<select/></td>";
            "</tr>";

            echo "<tr>
            <td style=\"width: 233px;\">Select the upper Snap Time</td>
            <td style=\"width: 233px;\"><select id=\"lowerSnap\" name=\"lowerSnap\" style=\"width: 200px;\">";
                for($count=0;$count<count($abc);$count++){
                echo "<option value=\"".  $abc[$count]['SNAP_ID']. "\">";
                echo $abc[$count]['SNAP_TIMES']. "</option>";

                } echo "<select/></td>";
            "</tr></table>";exit;

       }
       
       //Post processing
        if($this->getRequest()->isPost()){
            
            $selectedDate=$_POST['selectedDate'];
            if($_POST['todaylowerSnap']==$_POST['todayupperSnap']){
                    $upperSnap=$_POST['upperSnap'];
                    $lowerSnap=$_POST['lowerSnap'];
            }else{
                   $upperSnap=$_POST['todayupperSnap'];
                    $lowerSnap=$_POST['todaylowerSnap'];
                 }
            $procGetSharedPoolDayAvg="call GET_BUFFERPOOL_AGGREGATES('".$selectedDate."',:ret)";
            $resultShared=Application_Model_DBConnect::executeSP($_SESSION['USERNAME'],$_SESSION['PASSWORD'], $procGetSharedPoolDayAvg);
            $this->view->dayAvg=$resultShared;
            $this->view->selectedDate=$selectedDate;
            $this->view->upperSnap=$upperSnap;
            $this->view->lowerSnap=$lowerSnap;
            $procBreakDown="call get_bufferpool_sp(".$lowerSnap.",".$upperSnap.",:ret)";
            $resultBreak=Application_Model_DBConnect::executeSP($_SESSION['USERNAME'],$_SESSION['PASSWORD'], $procBreakDown);
            $this->view->breakAvg=$resultBreak;
        }
            
        }else{
                 $this->_redirect("/index/logout");
             }
        
    }
    
    
    
    public function redologAction(){
        if(isset($_SESSION['USERNAME'])){
        $queryRedoBuffer="SELECT name, value
                            FROM v\$sysstat
                            WHERE name like 'redo buffer allocation retries'";   
        $resultRedoBuffer=Application_Model_DBConnect::dbconnect($_SESSION['USERNAME'],$_SESSION['PASSWORD'],$queryRedoBuffer);
        $this->view->redoBufferVal=round(floatval($resultRedoBuffer['VALUE'][0]),2);
        $this->view->redoBufferName=$resultRedoBuffer['NAME'][0];
        
        $queryRedoLog="SELECT name, value
                            FROM v\$sysstat
                            WHERE name = 'redo log space requests'";   
        $resultRedoLog=Application_Model_DBConnect::dbconnect($_SESSION['USERNAME'],$_SESSION['PASSWORD'],$queryRedoLog);
        $this->view->redoLogVal=round(floatval($resultRedoLog['VALUE'][0]),2);
        $this->view->redoLogName=$resultRedoLog['NAME'][0];
        
        $queryRedoRatio="SELECT a.value/b.value 'redo_buffer_entries_ratio'
                            FROM v\$sysstat a, v\$sysstat b
                            WHERE a.name = 'redo buffer allocation retries'
                            AND b.name = 'redo entries'";
        $resultRedoRatio=Application_Model_DBConnect::dbconnect($_SESSION['USERNAME'],$_SESSION['PASSWORD'],$queryRedoRatio);
        $this->view->redoRatio=round(floatval($resultRedoRatio['redo_buffer_entries_ratio'][0]),2);
           
            






        //date processing stuff
      
        $curTime=strtotime("Now");
        //Can generate reports only for 8 days prior to today
        $startTime=$curTime-(60*60*24*8);
        $curDate = date( 'Y-m-d', $curTime );
        $nodays=  intval(($curTime-$startTime)/ (60 * 60 * 24));
        $this->view->dateArray=array();
        for($i=0;$i<=$nodays;$i++){
            $newdate=strtotime ( '-'.$i .' day' , strtotime ( $curDate ) ) ;
            $newdate = date ( 'Y-m-d' , $newdate );
            $this->view->dateArray[$i]=$newdate;
        }
        //Get the snaps for Today
        $procGetSnapsofToday="call GET_SNAPS_ONDATE('".$curDate."',:rc)";
        $resultToday=Application_Model_DBConnect::executeSPForCursor($_SESSION['USERNAME'],$_SESSION['PASSWORD'], $procGetSnapsofToday);
        $valToday=array();
        $i=0;
         while($i<100) {
                $temp=oci_fetch_array($resultToday, OCI_ASSOC);
            if($temp==false)
                break;
            $valToday[$i]= $temp;
            $i++;
            }
            
            $this->view->todaySnaps=$valToday;
        //End of get the snaps for today
        
        //Ajax Processing
       if($_GET["q"]!=''){
            $procGetSnapsonDate="call GET_SNAPS_ONDATE('".$_GET["q"]."',:rc)";
            $resultSnaps=Application_Model_DBConnect::executeSPForCursor($_SESSION['USERNAME'],$_SESSION['PASSWORD'], $procGetSnapsonDate);
            $abc=array(); 
            $i=0;
            while($i<100) {
                $temp=oci_fetch_array($resultSnaps, OCI_ASSOC);
            if($temp==false)
                break;
            $abc[$i]= $temp;
            $i++;
            }
            echo "<table style=\"margin-left:5px;\">
            <tr>
            <td style=\"width: 233px;\">Select the upper Snap Time</td>
            <td style=\"width: 233px;\"><select id=\"upperSnap\" name=\"upperSnap\" style=\"width: 200px;\">";
                for($count=0;$count<count($abc);$count++){
                echo "<option value=\"".$abc[$count]['SNAP_ID']."\">";
                echo $abc[$count]['SNAP_TIMES']."</option>";

                } echo "<select/></td>";
            "</tr>";

            echo "<tr>
            <td style=\"width: 233px;\">Select the upper Snap Time</td>
            <td style=\"width: 233px;\"><select id=\"lowerSnap\" name=\"lowerSnap\" style=\"width: 200px;\">";
                for($count=0;$count<count($abc);$count++){
                echo "<option value=\"".  $abc[$count]['SNAP_ID']. "\">";
                echo $abc[$count]['SNAP_TIMES']. "</option>";

                } echo "<select/></td>";
            "</tr></table>";exit;

       }
       
       //Post processing
        if($this->getRequest()->isPost()){
            $selectedDate=$_POST['selectedDate'];
            if($_POST['todaylowerSnap']==$_POST['todayupperSnap']){
                    $upperSnap=$_POST['upperSnap'];
                    $lowerSnap=$_POST['lowerSnap'];
            }else{
                   $upperSnap=$_POST['todayupperSnap'];
                    $lowerSnap=$_POST['todaylowerSnap'];
                 }
                 
            $procGetRedoDayAvg="call GET_REDOLOG_AGGREGATES('".$selectedDate."',:ret)";
            $resultShared=Application_Model_DBConnect::executeSP($_SESSION['USERNAME'],$_SESSION['PASSWORD'], $procGetRedoDayAvg);
            $this->view->dayAvg=floatval($resultShared)/(1024*1024);
            $this->view->selectedDate=$selectedDate;
            $this->view->upperSnap=$upperSnap;
            $this->view->lowerSnap=$lowerSnap;
            $procBreakDown="call get_redolog_sp(".$lowerSnap.",".$upperSnap.",:ret)";
            $resultBreak=Application_Model_DBConnect::executeSP($_SESSION['USERNAME'],$_SESSION['PASSWORD'], $procBreakDown);
            $this->view->breakAvg=floatval($resultBreak)/(1024*1024);
        }
          
            
        }else{
                 $this->_redirect("/index/logout");
             }
        
    }
    
  
    
      public function debugAction(){
          
    if(isset($_SESSION['USERNAME'])){       
          if($this->getRequest()->isPost()){
              
              $this->view->postSet=true;
              $query=trim($_POST['txtAreaQuery']); 
              $queryLength=strlen($query);
              if(substr($query, $queryLength-1)==';')
                   $query=substr($query,0,$queryLength-1);
              $this->view->queries=$query;
              
              $sysResult=Application_Model_DBConnect::dbconnect($_SESSION['USERNAME'],$_SESSION['PASSWORD'],$query);
              if ($sysResult[0]=='APPLICATION_ERROR')
    		{
                  var_dump("bad query");exit;
    			$this->view->badQuery=true;
    		}else{
                        $this->view->sysstat=$sysResult;
                        foreach($sysResult as $key=>$value){
                        $firstkey=$key;
                        break;
                        }
                        $this->view->paramCount=count($sysResult[$firstkey]);
                  }
              
          }
          
    }else{
             $this->_redirect("/index/logout");
         }
          
      }
      
      
      public function awrAction(){
          
          
     if(isset($_SESSION['USERNAME'])){   
          //Retrieve and popluate the dropdown with snap IDS
          $querySnapShotId="select snap_id,END_INTERVAL_TIME from dba_hist_snapshot order by snap_id";
          $snapIds=Application_Model_DBConnect::dbconnect($_SESSION['USERNAME'],$_SESSION['PASSWORD'],$querySnapShotId);
          $this->view->snapIdList=$snapIds['SNAP_ID'];
          $this->view->snapTimeList=$snapIds['END_INTERVAL_TIME'];
          
          //Get the current awr settings
          $procCall="call GET_SNAPSHOT_SETTINGS(:rc)";
          $result=Application_Model_DBConnect::executeSPForCursor($_SESSION['USERNAME'],$_SESSION['PASSWORD'], $procCall);
          $this->view->settings = oci_fetch_array($result, OCI_ASSOC); 
          
          
          //Get the existing baseline details
          $queryExistingBaseline="select * from DBA_HIST_BASELINE";
          $this->view->existingBaslines=Application_Model_DBConnect::dbconnect($_SESSION['USERNAME'],$_SESSION['PASSWORD'],$queryExistingBaseline);
          
          
          //Get the current retention perio for moving window baseline
          $queryGetMovingWindowSize="SELECT moving_window_size FROM  dba_hist_baseline WHERE  baseline_type ='MOVING_WINDOW'";
          $movingWindowSize=Application_Model_DBConnect::dbconnect($_SESSION['USERNAME'],$_SESSION['PASSWORD'],$queryGetMovingWindowSize);
          $this->view->movingWindowSize= intval($movingWindowSize['MOVING_WINDOW_SIZE'][0])*24*60;

          if($this->getRequest()->isPost()){
                            
              //Processing for creating a baseline
             if(isset($_POST['hdnCreateBaseline'])){
                  $procCallCreateBaseline= "begin DBMS_WORKLOAD_REPOSITORY.create_baseline(".$_POST['beginsnapid'].",".$_POST['endsnapid'].",'".strtoupper($_POST['baselinename'])."'); end;";
                  Application_Model_DBConnect::executeSP($_SESSION['USERNAME'],$_SESSION['PASSWORD'], $procCallCreateBaseline);
                  $queryExistingBaseline="select * from DBA_HIST_BASELINE";
                  $this->view->existingBaslines=Application_Model_DBConnect::dbconnect($_SESSION['USERNAME'],$_SESSION['PASSWORD'],$queryExistingBaseline);
             }
             
             
             //Processing change baseline settings
             
             if(isset($_POST['hdnChangeBaseline'])){
                 
                 $retention=  intval(trim($_POST['retention']));
                 $interval=intval(trim($_POST['interval']));
                 $procCallModifySettings="call CHANGE_SNAPSHOT_SETTINGS(".$retention.",".$interval.",:rc)";
                 $resultModifySettings=Application_Model_DBConnect::executeSPForCursor($_SESSION['USERNAME'],$_SESSION['PASSWORD'], $procCallModifySettings);
                 $this->view->settings = oci_fetch_array($resultModifySettings, OCI_ASSOC);    
                 
             }
             
             
             //Processing Drop SnapShot
             if(isset($_POST['hdnDropSnapshot'])){
                 $procCallDropSnapShot= "begin DBMS_WORKLOAD_REPOSITORY.drop_snapshot_range ( low_snap_id  =>".$_POST['lowerdropid'].",high_snap_id =>".$_POST['upperdropid'].");end;";
                  Application_Model_DBConnect::executeSP($_SESSION['USERNAME'],$_SESSION['PASSWORD'], $procCallDropSnapShot);
                  $querySnapShotId="select snap_id,END_INTERVAL_TIME from dba_hist_snapshot order by snap_id";
                  $snapIds=Application_Model_DBConnect::dbconnect($_SESSION['USERNAME'],$_SESSION['PASSWORD'],$querySnapShotId);
                   $this->view->snapIdList=$snapIds['SNAP_ID'];
                   $this->view->snapTimeList=$snapIds['END_INTERVAL_TIME'];
             }
            
             //Process create snap shot
             if(isset($_POST['hdnCreateSnapshot'])){
                $this->view->snapShotTaken=false; 
                $procCallCreateSnapShot= "begin DBMS_WORKLOAD_REPOSITORY.create_snapshot();end;";
                Application_Model_DBConnect::executeSP($_SESSION['USERNAME'],$_SESSION['PASSWORD'], $procCallCreateSnapShot); 
                $this->view->snapShotTaken=true;  
                $procCall="call GET_LATEST_SNAPSHOT(:rc)";
                $result=Application_Model_DBConnect::executeSPForCursor($_SESSION['USERNAME'],$_SESSION['PASSWORD'], $procCall);
                $this->view->latestSnap = oci_fetch_array($result, OCI_ASSOC); 
                $querySnapShotId="select snap_id,END_INTERVAL_TIME from dba_hist_snapshot order by snap_id";
                $snapIds=Application_Model_DBConnect::dbconnect($_SESSION['USERNAME'],$_SESSION['PASSWORD'],$querySnapShotId);
                $this->view->snapIdList=$snapIds['SNAP_ID'];
                $this->view->snapTimeList=$snapIds['END_INTERVAL_TIME'];
                
             }  
              
         //Processing for generate awr reports     
          if(isset($_POST['hdnGenerateawr'])){  
               $procCall="call GET_AWR_REPORT(".$_POST['lowergenerateid'].",".$_POST['uppergenerateid'].",:rc)";
               $refcur=Application_Model_DBConnect::executeSPForCursor($_SESSION['USERNAME'],$_SESSION['PASSWORD'], $procCall);
                 $i=0;
                 $fileName="awrreport_".$_POST['lowergenerateid']."_".$_POST['uppergenerateid'].".html";
                 $this->view->awrUrl="http://dbtuning.localhost/awrreports/".$fileName;
                 $fp = fopen("C:\wamp\www\dbtuning\public\awrreports\\".$fileName, 'w');
                 $nullCount=0;
                 $this->view->lowerGenerateID=$_POST['lowergenerateid'];
                 $this->view->upperGenerateID=$_POST['uppergenerateid'];
                 
                 $reportExists=true;
                 while($i<10000) {
                    $row = oci_fetch_array($refcur, OCI_ASSOC);                  
                    if($row==null){
                               $nullCount++;
                                  if($i==0){
                                        $reportExists=false;
                                         break;
                                   }else if($nullCount<20){
                                         continue;
                                   }else{
                                          break;
                                        }
                     }else{
                           fwrite($fp, $row['OUTPUT']);  
                          }
                       $i++;
                  }
                 fclose($fp);
                oci_free_statement($refcur);
                $this->view->reportExists=$reportExists;
           }
         }  
      }else{
                $this->_redirect("/index/logout");
           }
    
     }   

     public function addparamAction(){
         if(isset($_SESSION['USERNAME'])){
             
        $query1="select name,value from v\$parameter where name = 'processes'"; 
        $this->view->result1=Application_Model_DBConnect::dbconnect($_SESSION['USERNAME'],$_SESSION['PASSWORD'],$query1);
        $query2="select name,value from v\$sysstat where name like 'opened_cursor%'"; 
        $this->view->result2=Application_Model_DBConnect::dbconnect($_SESSION['USERNAME'],$_SESSION['PASSWORD'],$query2);
        $query3="select event as NAME,count(*) as VALUE from v\$session_wait group by event"; 
        $this->view->result3=Application_Model_DBConnect::dbconnect($_SESSION['USERNAME'],$_SESSION['PASSWORD'],$query3);
         
         //var_dump($this->view->result1);
         //var_dump($this->view->result2);exit;
         //var_dump($this->view->result3);exit;
             
         }else{
                $this->_redirect("/index/logout");
           }
     }
     
     public function redologfilesAction(){
         if(isset($_SESSION['USERNAME'])){
             
        $queryLog="select * from v\$log";   
        $resultlog=Application_Model_DBConnect::dbconnect($_SESSION['USERNAME'],$_SESSION['PASSWORD'],$queryLog);
        $this->view->logData=$resultlog;
        
        $queryLogFile="select * from v\$logfile";
        $this->view->logFileData=Application_Model_DBConnect::dbconnect($_SESSION['USERNAME'],$_SESSION['PASSWORD'],$queryLogFile);
        //var_dump($this->view->logFileData);exit;
        
        $queryGetEstimate="SELECT TARGET_MTTR,ESTIMATED_MTTR,WRITES_MTTR,WRITES_LOGFILE_SIZE, OPTIMAL_LOGFILE_SIZE FROM V\$INSTANCE_RECOVERY";
        $this->view->estimate=Application_Model_DBConnect::dbconnect($_SESSION['USERNAME'],$_SESSION['PASSWORD'],$queryGetEstimate);  
        //var_dump($this->view->estimate);exit;
        
         }else{
                $this->_redirect("/index/logout");
           }
         
     }
}

